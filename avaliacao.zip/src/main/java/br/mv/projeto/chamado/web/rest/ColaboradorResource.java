package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.domain.Colaborador;
import br.mv.projeto.chamado.repository.ColaboradorRepository;
import br.mv.projeto.chamado.service.ColaboradorService;
import br.mv.projeto.chamado.service.dto.ColaboradorDTO;
import br.mv.projeto.chamado.service.mapper.ColaboradorMapper;
import br.mv.projeto.chamado.web.rest.util.PaginationUtil;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class ColaboradorResource {

    private final Logger log = LoggerFactory.getLogger(ColaboradorResource.class);

    @Inject
    private ColaboradorRepository colaboradorRepository;

    @Inject
    private ColaboradorService colaboradorService;

    @Inject
    private ColaboradorMapper mapper;

    @RequestMapping(value = "/colaborador",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ColaboradorDTO>> list(final Pageable pageable) {
        try {
            Page<Colaborador> page = colaboradorRepository.findAll(pageable);
            List<ColaboradorDTO> dto = mapper.colaboradorToColaboradorDTO(page.getContent());
            HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/colaborador");
            return new ResponseEntity<>(dto, headers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error(ex.toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/colaborador/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ColaboradorDTO> colaborador(@PathVariable long id) {
        return colaboradorRepository.findOneById(id).map(p -> {
            ColaboradorDTO dto = mapper.colaboradorToColaboradorDTO(p);
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/colaborador",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody ColaboradorDTO dto, HttpServletRequest request) throws URISyntaxException {
        Colaborador colaborador = mapper.colaboradorDTOToColaborador(dto);
        colaboradorService.create(colaborador);
        dto = mapper.colaboradorToColaboradorDTO(colaborador);
        return ResponseEntity.created(new URI(Constants.RESOURCE_MAPPING + "/colaborador/" + colaborador.getId()))
                .body(dto);
    }
    
    @RequestMapping(value = "/colaborador",
            method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody ColaboradorDTO dto, HttpServletRequest request) throws URISyntaxException {
        return colaboradorRepository.findOneById(dto.getId()).map(p -> {
            Colaborador colaborador = mapper.colaboradorDTOToColaborador(dto);
            colaboradorService.update(colaborador);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/colaborador/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@PathVariable long id) {
        return colaboradorRepository.findOneById(id).map(p -> {
            colaboradorService.delete(p);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }
}
