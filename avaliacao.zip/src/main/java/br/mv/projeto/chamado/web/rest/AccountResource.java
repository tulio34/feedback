package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.repository.UsuarioRepository;
import br.mv.projeto.chamado.security.SecurityUtils;
import br.mv.projeto.chamado.service.dto.UsuarioDTO;
import br.mv.projeto.chamado.service.mapper.UsuarioMapper;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class AccountResource {

    private final Logger log = LoggerFactory.getLogger(AccountResource.class);

    @Inject
    private UsuarioRepository usuarioRepository;

    @Inject
    private UsuarioMapper mapper;

    @RequestMapping(value = "/account",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UsuarioDTO> account() {
        return usuarioRepository.findOneByUsuario(SecurityUtils.getCurrentUserLogin()).map(p -> {
            UsuarioDTO dto = mapper.usuarioToUsuarioDTO(p);
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        });
    }
}
