package br.mv.projeto.chamado.repository;

import br.mv.projeto.chamado.domain.Usuario;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author italo.teixeira
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    Optional<Usuario> findOneByUsuario(String usuario);
}
