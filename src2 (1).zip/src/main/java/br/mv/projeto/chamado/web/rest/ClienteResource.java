package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.domain.Cliente;
import br.mv.projeto.chamado.repository.ClienteRepository;
import br.mv.projeto.chamado.service.ClienteService;
import br.mv.projeto.chamado.service.dto.ClienteDTO;
import br.mv.projeto.chamado.service.mapper.ClienteMapper;
import br.mv.projeto.chamado.web.rest.util.PaginationUtil;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class ClienteResource {

    private final Logger log = LoggerFactory.getLogger(ClienteResource.class);

    @Inject
    private ClienteRepository clienteRepository;

    @Inject
    private ClienteService clienteService;

    @Inject
    private ClienteMapper mapper;

    @RequestMapping(value = "/cliente",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ClienteDTO>> list(final Pageable pageable) {
        try {
            Page<Cliente> page = clienteRepository.findAll(pageable);
            List<ClienteDTO> dto = mapper.clienteToClienteDTO(page.getContent());
            HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/cliente");
            return new ResponseEntity<>(dto, headers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error(ex.toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/cliente/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ClienteDTO> cliente(@PathVariable long id) {
        return clienteRepository.findOneById(id).map(p -> {
            ClienteDTO dto = mapper.clienteToClienteDTO(p);
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/cliente",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody ClienteDTO dto, HttpServletRequest request) throws URISyntaxException {
        Cliente cliente = mapper.clienteDTOToCliente(dto);
        clienteService.create(cliente);
        dto = mapper.clienteToClienteDTO(cliente);
        return ResponseEntity.created(new URI(Constants.RESOURCE_MAPPING + "/cliente/" + cliente.getId()))
                .body(dto);
    }
    
    @RequestMapping(value = "/cliente",
            method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody ClienteDTO dto, HttpServletRequest request) throws URISyntaxException {
        return clienteRepository.findOneById(dto.getId()).map(p -> {
            Cliente cliente = mapper.clienteDTOToCliente(dto);
            clienteService.update(cliente);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/cliente/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@PathVariable long id) {
        return clienteRepository.findOneById(id).map(p -> {
            clienteService.delete(p);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }
}
