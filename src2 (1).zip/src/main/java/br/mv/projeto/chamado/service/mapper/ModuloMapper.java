package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Modulo;
import br.mv.projeto.chamado.service.dto.ModuloDTO;
import java.util.List;
import org.mapstruct.Mapper;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {})
public interface ModuloMapper {

    ModuloDTO moduloToModuloDTO(Modulo modulo);

    List<ModuloDTO> moduloToModuloDTO(List<Modulo> modulo);

    Modulo moduloDTOToModulo(ModuloDTO moduloDTO);

    List<Modulo> moduloDTOToModulo(List<ModuloDTO> moduloDTO);

}
