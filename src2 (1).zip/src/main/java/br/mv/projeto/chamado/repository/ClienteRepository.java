package br.mv.projeto.chamado.repository;

import br.mv.projeto.chamado.domain.Cliente;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author italo.teixeira
 */
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    Optional<Cliente> findOneById(long id);
}
