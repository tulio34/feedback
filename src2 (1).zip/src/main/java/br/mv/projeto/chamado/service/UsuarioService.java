package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Usuario;
import br.mv.projeto.chamado.repository.UsuarioRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class UsuarioService {

    @Inject
    private UsuarioRepository usuarioRepository;

    public void create(Usuario usuario) {
        usuario.setId(null);
        usuarioRepository.save(usuario);
    }
    
    @Transactional
    public void update(Usuario usuario) {
        
        usuarioRepository.save(usuario);
    }
    
    @Transactional
    public void delete(Usuario usuario) {
        usuarioRepository.delete(usuario);
    }
}
