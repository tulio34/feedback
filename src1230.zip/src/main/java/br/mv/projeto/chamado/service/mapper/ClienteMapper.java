package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Cliente;
import br.mv.projeto.chamado.service.dto.ClienteDTO;
import java.util.List;
import org.mapstruct.Mapper;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {})
public interface ClienteMapper {

    ClienteDTO clienteToClienteDTO(Cliente cliente);

    List<ClienteDTO> clienteToClienteDTO(List<Cliente> cliente);

    Cliente clienteDTOToCliente(ClienteDTO clienteDTO);

    List<Cliente> clienteDTOToCliente(List<ClienteDTO> clienteDTO);

}
