package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Setor;
import br.mv.projeto.chamado.service.dto.SetorDTO;
import java.util.List;
import org.mapstruct.Mapper;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {})
public interface SetorMapper {

    SetorDTO setorToSetorDTO(Setor setor);

    List<SetorDTO> setorToSetorDTO(List<Setor> setor);

    Setor setorDTOToSetor(SetorDTO setorDTO);

    List<Setor> setorDTOToSetor(List<SetorDTO> setorDTO);

}
