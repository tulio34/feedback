package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Cliente;
import br.mv.projeto.chamado.repository.ClienteRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class ClienteService {

    @Inject
    private ClienteRepository clienteRepository;

    public void create(Cliente cliente) {
        cliente.setId(null);
        clienteRepository.save(cliente);
    }
    
    @Transactional
    public void update(Cliente cliente) {
        
        clienteRepository.save(cliente);
    }
    
    @Transactional
    public void delete(Cliente cliente) {
        clienteRepository.delete(cliente);
    }
}
