package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Usuario;
import br.mv.projeto.chamado.service.dto.UsuarioDTO;
import java.util.List;
import org.mapstruct.Mapper;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {})
public interface UsuarioMapper {
    
    UsuarioDTO usuarioToUsuarioDTO(Usuario usuario);

    List<UsuarioDTO> usuarioToUsuarioDTO(List<Usuario> usuario);
    
    Usuario usuarioDTOToUsuario(UsuarioDTO usuarioDTO);
    
    List<Usuario> usuarioDTOToUsuario(List<UsuarioDTO> usuarioDTO);

}
