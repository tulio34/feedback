package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.domain.Usuario;
import br.mv.projeto.chamado.repository.UsuarioRepository;
import br.mv.projeto.chamado.service.dto.UsuarioDTO;
import br.mv.projeto.chamado.service.mapper.UsuarioMapper;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class UsuarioResource {

    private final Logger log = LoggerFactory.getLogger(UsuarioResource.class);

    @Inject
    private UsuarioRepository usuarioRepository;
    
    @Inject
    private UsuarioMapper mapper;

    @RequestMapping(value = "/usuario",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<UsuarioDTO>> list(final Pageable pageable) {
        try {
            Page<Usuario> page = usuarioRepository.findAll(pageable);
            List<UsuarioDTO> dto = mapper.usuarioToUsuarioDTO(page.getContent());
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        } catch (Exception ex) {
            log.error(ex.toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
