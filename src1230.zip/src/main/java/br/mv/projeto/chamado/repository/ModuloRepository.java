package br.mv.projeto.chamado.repository;

import br.mv.projeto.chamado.domain.Modulo;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author italo.teixeira
 */
public interface ModuloRepository extends JpaRepository<Modulo, Integer> {

    Optional<Modulo> findOneById(long id);
}
