package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Setor;
import br.mv.projeto.chamado.repository.SetorRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class SetorService {

    @Inject
    private SetorRepository setorRepository;

    public void create(Setor setor) {
        setor.setId(null);
        setorRepository.save(setor);
    }
    
    @Transactional
    public void update(Setor setor) {
        
        setorRepository.save(setor);
    }
    
    @Transactional
    public void delete(Setor setor) {
        setorRepository.delete(setor);
    }
}
