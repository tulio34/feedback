package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Modulo;
import br.mv.projeto.chamado.repository.ModuloRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class ModuloService {

    @Inject
    private ModuloRepository moduloRepository;

    public void create(Modulo modulo) {
        modulo.setId(null);
        moduloRepository.save(modulo);
    }
    
    @Transactional
    public void update(Modulo modulo) {
        
        moduloRepository.save(modulo);
    }
    
    @Transactional
    public void delete(Modulo modulo) {
        moduloRepository.delete(modulo);
    }
}
