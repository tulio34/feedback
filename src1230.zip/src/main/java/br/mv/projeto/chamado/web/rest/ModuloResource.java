package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.domain.Modulo;
import br.mv.projeto.chamado.repository.ModuloRepository;
import br.mv.projeto.chamado.service.ModuloService;
import br.mv.projeto.chamado.service.dto.ModuloDTO;
import br.mv.projeto.chamado.service.mapper.ModuloMapper;
import br.mv.projeto.chamado.web.rest.util.PaginationUtil;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class ModuloResource {

    private final Logger log = LoggerFactory.getLogger(ModuloResource.class);

    @Inject
    private ModuloRepository moduloRepository;

    @Inject
    private ModuloService moduloService;

    @Inject
    private ModuloMapper mapper;

    @RequestMapping(value = "/modulo",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ModuloDTO>> list(final Pageable pageable) {
        try {
            Page<Modulo> page = moduloRepository.findAll(pageable);
            List<ModuloDTO> dto = mapper.moduloToModuloDTO(page.getContent());
            HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/modulo");
            return new ResponseEntity<>(dto, headers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error(ex.toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/modulo/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ModuloDTO> modulo(@PathVariable long id) {
        return moduloRepository.findOneById(id).map(p -> {
            ModuloDTO dto = mapper.moduloToModuloDTO(p);
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/modulo",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody ModuloDTO dto, HttpServletRequest request) throws URISyntaxException {
        Modulo modulo = mapper.moduloDTOToModulo(dto);
        moduloService.create(modulo);
        dto = mapper.moduloToModuloDTO(modulo);
        return ResponseEntity.created(new URI(Constants.RESOURCE_MAPPING + "/modulo/" + modulo.getId()))
                .body(dto);
    }
    
    @RequestMapping(value = "/modulo",
            method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody ModuloDTO dto, HttpServletRequest request) throws URISyntaxException {
        return moduloRepository.findOneById(dto.getId()).map(p -> {
            Modulo modulo = mapper.moduloDTOToModulo(dto);
            moduloService.update(modulo);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/modulo/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@PathVariable long id) {
        return moduloRepository.findOneById(id).map(p -> {
            moduloService.delete(p);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }
}
