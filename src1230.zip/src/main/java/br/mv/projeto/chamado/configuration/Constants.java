package br.mv.projeto.chamado.configuration;

/**
 *
 * @author italo.teixeira
 */
public final class Constants {
    
    public static final String RESOURCE_MAPPING = "/api";
}
