package br.mv.projeto.chamado.security;

/**
 * Constants for Spring Security authorities.
 */
public final class AuthoritiesConstants {

    public static final String GESTOR = "GESTOR";

    public static final String AVALIADOR = "AVALIADOR";

    public static final String ATENDENTE = "ATENDENTE";

    private AuthoritiesConstants() {
    }
}
