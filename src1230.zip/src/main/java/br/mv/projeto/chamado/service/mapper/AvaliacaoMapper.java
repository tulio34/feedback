package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Avaliacao;
import br.mv.projeto.chamado.service.dto.AvaliacaoDTO;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {ColaboradorMapper.class, ClienteMapper.class})
public interface AvaliacaoMapper {

    @Mappings({
        @Mapping(source = "idColaborador",  target = "colaborador"),
        @Mapping(source = "idCliente",  target = "cliente")
    })
    AvaliacaoDTO avaliacaoToAvaliacaoDTO(Avaliacao avaliacao);

    List<AvaliacaoDTO> avaliacaoToAvaliacaoDTO(List<Avaliacao> avaliacao);

    @Mappings({
        @Mapping(target = "idColaborador", source = "colaborador"),
        @Mapping(target = "idCliente",  source = "cliente")
    })
    Avaliacao avaliacaoDTOToAvaliacao(AvaliacaoDTO avaliacaoDTO);

    List<Avaliacao> avaliacaoDTOToAvaliacao(List<AvaliacaoDTO> avaliacaoDTO);

}
