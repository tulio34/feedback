package br.mv.projeto.chamado.service.mapper;

import br.mv.projeto.chamado.domain.Colaborador;
import br.mv.projeto.chamado.domain.Colaborador;
import br.mv.projeto.chamado.service.dto.ColaboradorDTO;
import br.mv.projeto.chamado.service.dto.ColaboradorDTO;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 *
 * @author italo.teixeira
 */
@Mapper(componentModel = "spring", uses = {ModuloMapper.class})
public interface ColaboradorMapper {

    @Mappings({
        @Mapping(source = "idModulo", target = "modulo")
    })
    ColaboradorDTO colaboradorToColaboradorDTO(Colaborador colaborador);

    List<ColaboradorDTO> colaboradorToColaboradorDTO(List<Colaborador> colaborador);

    @Mappings({
        @Mapping(target = "idModulo", source = "modulo")
    })
    Colaborador colaboradorDTOToColaborador(ColaboradorDTO colaboradorDTO);

    List<Colaborador> colaboradorDTOToColaborador(List<ColaboradorDTO> colaboradorDTO);

}
