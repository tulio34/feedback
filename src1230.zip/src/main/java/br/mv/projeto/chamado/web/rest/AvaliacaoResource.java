package br.mv.projeto.chamado.web.rest;

import br.mv.projeto.chamado.configuration.Constants;
import br.mv.projeto.chamado.domain.Avaliacao;
import br.mv.projeto.chamado.repository.AvaliacaoRepository;
import br.mv.projeto.chamado.service.AvaliacaoService;
import br.mv.projeto.chamado.service.dto.AvaliacaoDTO;
import br.mv.projeto.chamado.service.mapper.AvaliacaoMapper;
import br.mv.projeto.chamado.web.rest.util.PaginationUtil;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author italo.teixeira
 */
@RestController
@RequestMapping(Constants.RESOURCE_MAPPING)
public class AvaliacaoResource {

    private final Logger log = LoggerFactory.getLogger(AvaliacaoResource.class);

    @Inject
    private AvaliacaoRepository avaliacaoRepository;

    @Inject
    private AvaliacaoService avaliacaoService;

    @Inject
    private AvaliacaoMapper mapper;

    @RequestMapping(value = "/avaliacao",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AvaliacaoDTO>> list(final Pageable pageable) {
        try {
            Page<Avaliacao> page = avaliacaoRepository.findAll(pageable);
            List<AvaliacaoDTO> dto = mapper.avaliacaoToAvaliacaoDTO(page.getContent());
            HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/avaliacao");
            return new ResponseEntity<>(dto, headers, HttpStatus.OK);
        } catch (Exception ex) {
            log.error(ex.toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/avaliacao/{id}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AvaliacaoDTO> avaliacao(@PathVariable long id) {
        return avaliacaoRepository.findOneById(id).map(p -> {
            AvaliacaoDTO dto = mapper.avaliacaoToAvaliacaoDTO(p);
            return new ResponseEntity<>(dto, null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/avaliacao",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody AvaliacaoDTO dto, HttpServletRequest request) throws URISyntaxException {
        Avaliacao avaliacao = mapper.avaliacaoDTOToAvaliacao(dto);
        avaliacaoService.create(avaliacao);
        dto = mapper.avaliacaoToAvaliacaoDTO(avaliacao);
        return ResponseEntity.created(new URI(Constants.RESOURCE_MAPPING + "/avaliacao/" + avaliacao.getId()))
                .body(dto);
    }
    
    @RequestMapping(value = "/avaliacao",
            method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody AvaliacaoDTO dto, HttpServletRequest request) throws URISyntaxException {
        return avaliacaoRepository.findOneById(dto.getId()).map(p -> {
            Avaliacao avaliacao = mapper.avaliacaoDTOToAvaliacao(dto);
            avaliacaoService.update(avaliacao);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }

    @RequestMapping(value = "/avaliacao/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@PathVariable long id) {
        return avaliacaoRepository.findOneById(id).map(p -> {
            avaliacaoService.delete(p);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }).orElseGet(() -> {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        });
    }
}
