package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Colaborador;
import br.mv.projeto.chamado.repository.ColaboradorRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class ColaboradorService {

    @Inject
    private ColaboradorRepository colaboradorRepository;

    public void create(Colaborador colaborador) {
        colaborador.setId(null);
        colaboradorRepository.save(colaborador);
    }
    
    @Transactional
    public void update(Colaborador colaborador) {
        
        colaboradorRepository.save(colaborador);
    }
    
    @Transactional
    public void delete(Colaborador colaborador) {
        colaboradorRepository.delete(colaborador);
    }
}
