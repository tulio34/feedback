package br.mv.projeto.chamado.security;

/**
 *
 * @author Unknown
 */
public enum Perfil {
    AVALIADOR,
    GESTOR
}
