package br.mv.projeto.chamado.service.dto;

import br.mv.projeto.chamado.security.Perfil;

/**
 *
 * @author italo.teixeira
 */
public class UsuarioDTO {

    private Long id;
    private String nome;
    private String usuario;
    private Perfil perfil;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }
}
