package br.mv.projeto.chamado.service;

import br.mv.projeto.chamado.domain.Avaliacao;
import br.mv.projeto.chamado.repository.AvaliacaoRepository;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author italo.teixeira
 */
@Service
@Transactional
public class AvaliacaoService {

    @Inject
    private AvaliacaoRepository avaliacaoRepository;

    public void create(Avaliacao avaliacao) {
        avaliacao.setId(null);
        avaliacaoRepository.save(avaliacao);
    }
    
    @Transactional
    public void update(Avaliacao avaliacao) {
        
        avaliacaoRepository.save(avaliacao);
    }
    
    @Transactional
    public void delete(Avaliacao avaliacao) {
        avaliacaoRepository.delete(avaliacao);
    }
}
