package br.mv.projeto.chamado.repository;

import br.mv.projeto.chamado.domain.Setor;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author italo.teixeira
 */
public interface SetorRepository extends JpaRepository<Setor, Integer> {

    Optional<Setor> findOneById(long id);
}
