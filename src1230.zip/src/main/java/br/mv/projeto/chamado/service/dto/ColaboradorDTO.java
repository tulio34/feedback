package br.mv.projeto.chamado.service.dto;

/**
 *
 * @author italo.teixeira
 */
public class ColaboradorDTO {

    private Long id;
    private String nome;
    private SetorDTO setor;
    private ModuloDTO modulo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public SetorDTO getSetor() {
        return setor;
    }

    public void setSetor(SetorDTO setor) {
        this.setor = setor;
    }

    public ModuloDTO getModulo() {
        return modulo;
    }

    public void setModulo(ModuloDTO modulo) {
        this.modulo = modulo;
    }

}
